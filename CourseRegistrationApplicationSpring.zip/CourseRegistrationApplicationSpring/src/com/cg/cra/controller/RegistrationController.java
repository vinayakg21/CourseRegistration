package com.cg.cra.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.cra.entity.Course;
import com.cg.cra.entity.Registration;
import com.cg.cra.service.RegistrationService;

@Controller
public class RegistrationController {

	@Autowired
	RegistrationService rser;
	
	@RequestMapping("home")
	public String goHome(Model model){
		
		List<Course> clist = rser.getAllCourses();
		model.addAttribute("clist", clist);
		model.addAttribute("reg",new Registration());
		return "Register";
		
	}
	
	
	@RequestMapping("register")
	public String register(@ModelAttribute("reg") @Valid Registration reg, BindingResult res,Model model){
		
		if(res.hasErrors()){
			List<Course> clist = rser.getAllCourses();
			model.addAttribute("clist",clist);
			model.addAttribute("reg",reg);
			return "Register";
		}
		else
		{
			long regid = rser.insertRegistration(reg);
			model.addAttribute("regId",regid);
			return "Success";
		}
	}
	
	@RequestMapping("searchPage")
	public String goSearch(Model model){		
		return "Search";		
	}
	
	@RequestMapping("searchAction")
	public String searchUser(Model model ,
			  @RequestParam("regId") Integer regId){
		
		Registration reg = rser.getAllStudents(regId);
		
		model.addAttribute("reg",reg);
		
				return "StudentInfo";
	}
	
	@RequestMapping("deletePage")
	public String goDelete(Model model){		
		return "DeletePage";		
	}
	
	@RequestMapping("deleteAction")
	public String deleteUser(Model model ,
			  @RequestParam("regId") Integer regId){
		
		rser.deleteStudents(regId);
		
		model.addAttribute("msg","Deleted Successfully");
		
				return "DeleteSuccess";
	}
	
	@RequestMapping("updatePage")
	public String goUpdate(Model model){		
		return "UpdatePage";		
	}
		
	@RequestMapping("updateAction")
	public String updateUser(Model model ,
			  @RequestParam("regId") Integer regId){
		
		Registration reg = rser.getAllStudents(regId);
		
		List<Course> clist = rser.getAllCourses();
		model.addAttribute("clist", clist);
		model.addAttribute("reg",reg);
		
				return "UpdateForm";
	}
	
	@RequestMapping("update")
	public String update(@ModelAttribute("reg") @Valid Registration reg, BindingResult res,Model model){
		
		if(res.hasErrors()){
			List<Course> clist = rser.getAllCourses();
			model.addAttribute("clist",clist);
			model.addAttribute("reg",reg);
			return "UpdateForm";
		}
		else
		{
			rser.updateStudent(reg);
			model.addAttribute("msg","Successfully Updated");
			return "UpdateSuccess";
		}
	}
}

