package com.cg.cra.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Registration {

	@Override
	public String toString() {
		return "Registration [regId=" + regId + ", studentName=" + studentName
				+ ", phone=" + phone + ", courseId=" + courseId + "]";
	}

	@Id
	@Column(name="reg_id")
	@SequenceGenerator(name="Id_seq", sequenceName="seq_reg_id",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="Id_seq")
	private Integer regId;
	
	@Column(name="student_name")
	@NotEmpty(message="Student name is mandatory")
	@Pattern(regexp="[A-Z][a-z]{2,}", message="Student name should start with Captital letter & should contain minimum 3 digits")
	private String studentName;
	
	
	
	@Column(name="phone")
	@NotEmpty(message="Please Enter Mobile Number")
	@Pattern(regexp="[0-9]{10}", message="Phone number should contain 10 digits only")
	private String phone;
	
	@Column(name="course_id")
	private int courseId;
	
	public Registration() {
		// TODO Auto-generated constructor stub
	}

	public Integer getRegId() {
		return regId;
	}

	public void setRegId(Integer regId) {
		this.regId = regId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	
	
}
