package com.cg.cra.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.cra.entity.Course;
import com.cg.cra.entity.Registration;


@Repository
public class RegistrationDaoImpl implements RegistrationDao {
	
	@PersistenceContext
	EntityManager em;
	

	@Override
	public long insertRegistartion(Registration reg) {
		// TODO Auto-generated method stub
		em.persist(reg);
		return reg.getRegId();
	}

	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		String jpql = "Select course from Course course";
		TypedQuery<Course> query = em.createQuery(jpql, Course.class);
		return query.getResultList();
	}

	@Override
	public Registration getAllStudents(Integer regId) {
		// TODO Auto-generated method stub
		return em.find(Registration.class, regId);
	}

	@Override
	public void deleteStudents(Integer regId) {
		// TODO Auto-generated method stub
		Registration reg= em.find(Registration.class, regId);
		em.remove(reg);
	}

	@Override
	public void updateStudent(Registration reg) {
		// TODO Auto-generated method stub
		
		System.out.println(reg);
		em.merge(reg);
	}

}
