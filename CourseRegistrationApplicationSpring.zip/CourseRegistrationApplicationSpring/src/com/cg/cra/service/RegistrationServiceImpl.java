package com.cg.cra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.cra.dao.RegistrationDao;
import com.cg.cra.entity.Course;
import com.cg.cra.entity.Registration;


@Service
@Transactional
public class RegistrationServiceImpl implements RegistrationService {

	@Autowired
	RegistrationDao rdao;	
	
	@Override
	public long insertRegistration(Registration reg) {
		// TODO Auto-generated method stub
		return rdao.insertRegistartion(reg);
	}

	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		return rdao.getAllCourses();
	}

	@Override
	public Registration getAllStudents(Integer regId) {
		// TODO Auto-generated method stub
		return rdao.getAllStudents(regId);
	}

	@Override
	public void deleteStudents(Integer regId) {
		// TODO Auto-generated method stub
		rdao.deleteStudents(regId);
	}

	@Override
	public void updateStudent(Registration reg) {
		// TODO Auto-generated method stub
		rdao.updateStudent(reg);
	}

}
