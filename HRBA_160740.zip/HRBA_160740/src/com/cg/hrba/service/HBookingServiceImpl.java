package com.cg.hrba.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hrba.dao.HBookingDao;
import com.cg.hrba.entity.Booking;
import com.cg.hrba.entity.Hotel;

@Service
@Transactional
public class HBookingServiceImpl implements HBookingService {

	@Autowired
	HBookingDao hdao;
	
	@Override
	public List<Hotel> getAllHotels() {
		// TODO Auto-generated method stub
		return hdao.getAllHotels();
	}

	@Override
	public long insertRegistration(Booking book) {
		// TODO Auto-generated method stub
		return hdao.insertRegistration(book);
	}

	@Override
	public long calculateAmount(int hotelId) {
		// TODO Auto-generated method stub
		return hdao.calculateAmount(hotelId);
	}

}
