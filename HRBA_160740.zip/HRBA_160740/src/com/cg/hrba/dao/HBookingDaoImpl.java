package com.cg.hrba.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import com.cg.hrba.entity.Booking;
import com.cg.hrba.entity.Hotel;

@Repository
public class HBookingDaoImpl implements HBookingDao {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<Hotel> getAllHotels() {
		// TODO Auto-generated method stub
		
		String jpql = "Select hotel from Hotel hotel";
		TypedQuery<Hotel> query = em.createQuery(jpql, Hotel.class);
		return query.getResultList();
	}

	@Override
	public long insertRegistration(Booking book) {
		// TODO Auto-generated method stub
		em.persist(book);
		return book.getBookingId();
	}

	@Override
	public long calculateAmount(int hotelId) {
		// TODO Auto-generated method stub
		String str=
				"select hotel from Hotel hotel where hotel.hotelId=:hId";
				TypedQuery<Hotel> query= em.createQuery(str, Hotel.class);
				query.setParameter("hId", hotelId);
				Hotel hotel = query.getSingleResult();
				return hotel.getRate();
	}

}
