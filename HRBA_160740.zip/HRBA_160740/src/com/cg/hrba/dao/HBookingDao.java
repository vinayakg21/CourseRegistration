package com.cg.hrba.dao;

import java.util.List;

import com.cg.hrba.entity.Booking;
import com.cg.hrba.entity.Hotel;


public interface HBookingDao {

	List<Hotel> getAllHotels();

	long insertRegistration(Booking book);

	long calculateAmount(int hotelId);
}
