package com.cg.hrba.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.hrba.entity.Booking;
import com.cg.hrba.entity.Hotel;
import com.cg.hrba.service.HBookingService;


@Controller
public class BookingController {

	@Autowired
	HBookingService hser;
	
	@RequestMapping("home")
	public String goHome(Model model){
		
		List<Hotel> hlist = hser.getAllHotels();
		model.addAttribute("hlist", hlist);
		model.addAttribute("book",new Booking());
		return "BookingDetails";
		
	}
	
	@RequestMapping("booking")
	public String register(@ModelAttribute("book") @Valid Booking book, BindingResult res,Model model){
		/*public String register(@ModelAttribute("book") Booking book,Model model){*/
		
		if(res.hasErrors()){
			List<Hotel> hlist = hser.getAllHotels();
			model.addAttribute("hlist", hlist);
			model.addAttribute("book",book);
			return "BookingDetails";
		}
		else
		{
			long amount = hser.calculateAmount(book.getHotelId());
			
			long totalAmount = amount*book.getNoOfRooms();
			
			book.setAmount(totalAmount);
			
			long bookId = hser.insertRegistration(book);
			model.addAttribute("bookId",bookId);
			return "BookingConfirmation";
		}
	}
}
