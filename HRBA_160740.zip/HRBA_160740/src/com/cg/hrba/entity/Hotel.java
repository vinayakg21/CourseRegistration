package com.cg.hrba.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hoteldetails")
public class Hotel {
	
	@Id
	@Column(name="id")
	private int hotelId;
	
	@Column(name="name")
	private String hotelName;
	
	@Column(name="rating")
	private String rating;
	
	@Column(name="rate")
	private long rate;
	
	@Column(name="availablerooms")
	private int availableRooms;

	public Hotel() {
		// TODO Auto-generated constructor stub
	}
	
	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public long getRate() {
		return rate;
	}

	public void setRate(long rate) {
		this.rate = rate;
	}

	public int getAvailableRooms() {
		return availableRooms;
	}

	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}

}
