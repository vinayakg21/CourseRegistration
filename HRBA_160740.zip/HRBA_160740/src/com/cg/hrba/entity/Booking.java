package com.cg.hrba.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="bookingdetails")
public class Booking {

	@Id
	@Column(name="id")
	@SequenceGenerator(name="Id_seq", sequenceName="seq_booking_id",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="Id_seq")
	private long bookingId;
	
	@Column(name="customername")
	@NotEmpty(message="Customer name is mandatory")
	@Pattern(regexp="[A-Z][a-z]{2,}", message="Customer name should start with Captital letter & should contain minimum 3 digits")
	private String customerName;
	
	@Column(name="hotelid")
	private int hotelId;
	
	@Column(name="noofrooms")
	@NotNull(message="Please Enter No of Rooms")
	private int noOfRooms;
	
	@Column(name="amount")
	private double amount;
	
	public Booking() {
		// TODO Auto-generated constructor stub
	}

	public long getBookingId() {
		return bookingId;
	}

	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public int getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	
	
}
